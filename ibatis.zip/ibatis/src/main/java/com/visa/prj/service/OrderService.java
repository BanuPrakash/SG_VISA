package com.visa.prj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.visa.prj.entity.Order;
import com.visa.prj.entity.Product;
import com.visa.prj.mapper.OrderMapper;
import com.visa.prj.mapper.ProductMapper;

@Service
public class OrderService {
	@Autowired
	private ProductMapper productMapper;
	
	@Autowired
	private OrderMapper orderMapper;
	
	public List<Order> getOrders() {
		return orderMapper.getOrders();
	}
	public List<Product> getProducts() {
		return productMapper.getProducts();
	}
	
	public Product getProduct(int id) {
		return productMapper.getProduct(id);
	}
	
	@Transactional
	public void addProduct(Product p) {
		productMapper.addProduct(p);
		System.out.println(p.getId() + " added !!!");
	}
}
