package com.visa.prj.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {

	private int id;
	
	private double total;
	
	private Customer customer = new Customer();
	
	private List<LineItem> items = new ArrayList<>();
	
	private Date orderDate;

	public Order() {
	}

	public Order(int id, double total, Customer customer, List<LineItem> items, Date orderDate) {
		this.id = id;
		this.total = total;
		this.customer = customer;
		this.items = items;
		this.orderDate = orderDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<LineItem> getItems() {
		return items;
	}

	public void setItems(List<LineItem> items) {
		this.items = items;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	
}





