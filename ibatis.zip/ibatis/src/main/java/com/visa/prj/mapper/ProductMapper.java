package com.visa.prj.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.visa.prj.entity.Product;

public interface ProductMapper {
	@Select("SELECT * FROM products")
	public List<Product> getProducts();
	
	@Select("SELECT * FROM products where id = #{id}")
	public Product getProduct(@Param("id") int id);
	
	@Insert("INSERT INTO products (name,price,quantity) values (#{name},#{price},#{quantity})")
	@SelectKey(keyProperty="id",resultType=int.class,statement="SELECT LAST_INSERT_ID() AS id", before=false)
	public int addProduct(Product p);
}
