package com.visa.prj.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.visa.prj.entity.Customer;
import com.visa.prj.entity.LineItem;
import com.visa.prj.entity.Order;
import com.visa.prj.entity.Product;

public interface OrderMapper {
	@Select("SELECT * FROM orders")
	@Results(value = {
			@Result(property="id", column="id"),
			@Result(property="orderDate", column="order_date"),
			@Result(property="total", column="total"),
			@Result(property="customer", column="customer_id", javaType=Customer.class, 
			one=@One(select="com.banumy.ibatis.mapper.CustomerMapper.getCustomer")),
			@Result(property="items", column="id", javaType=List.class, many=@Many(select="getItems"))
		})
	public List<Order> getOrders();
	
	@Select("select * from items where order_id = #{id}")
	@Results({
		@Result(property="product", 
				column="product_id", javaType=Product.class, 
				one =@One(select="com.banumy.ibatis.mapper.ProductMapper.getProduct"))
	})
	public List<LineItem> getItems(@Param("id") int orderId);
}
