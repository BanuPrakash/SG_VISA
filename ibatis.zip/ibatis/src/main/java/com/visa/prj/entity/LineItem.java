package com.visa.prj.entity;

public class LineItem {
	private int id;
	
	private Product product;
	
	private int qty;
	
	private double price;

	public LineItem() {
	}

	public LineItem(int id, Product product, int qty, double price) {
		this.id = id;
		this.product = product;
		this.qty = qty;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
