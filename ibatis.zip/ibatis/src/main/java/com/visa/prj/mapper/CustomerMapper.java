package com.visa.prj.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.visa.prj.entity.Customer;

public interface CustomerMapper {
	@Select("SELECT * FROM customers where id = #{id}")
	@Results(
			{
			@Result(column="first_name", property="firstName"),
			@Result(column="last_name", property="lastName")
			})
	public Customer getCustomer(@Param("id") int id);
}
