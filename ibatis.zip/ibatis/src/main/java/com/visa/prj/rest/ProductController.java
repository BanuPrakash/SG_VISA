package com.visa.prj.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.visa.prj.entity.Order;
import com.visa.prj.entity.Product;
import com.visa.prj.service.OrderService;

@RestController
public class ProductController {

	@Autowired
	private OrderService orderService;
	
	
	@RequestMapping(value="/products", method=RequestMethod.POST)
	public @ResponseBody Product addProduct(@RequestBody Product p) {
		orderService.addProduct(p);
		return p;
	}
	
	@RequestMapping(value="/orders", method=RequestMethod.GET)
	public @ResponseBody List<Order> getOrders() {
		return orderService.getOrders();
	}
	
	
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public @ResponseBody List<Product> getProducts() {
		return orderService.getProducts();
	}
	
	@RequestMapping(value="/products/{id}", method=RequestMethod.GET)
	public @ResponseBody Product getProducts(@PathVariable("id") int id) {
		return orderService.getProduct(id);
	}
	
	
}
